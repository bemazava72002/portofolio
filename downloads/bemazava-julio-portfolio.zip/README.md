# Portfolio BEMAZAVA Julio

## 🚀 Installation et démarrage

### Prérequis
- Node.js (version 16 ou supérieure)
- npm ou yarn

### Installation
1. Extraire l'archive ZIP
2. Ouvrir un terminal dans le dossier du projet
3. Installer les dépendances :
   ```bash
   npm install
   ```

### Démarrage en développement
```bash
npm run dev
```

Le site sera accessible sur http://localhost:3000

### Build pour la production
```bash
npm run build
npm start
```

## 🛠️ Technologies utilisées
- Next.js 13
- React 18
- TypeScript
- Tailwind CSS
- Shadcn/ui
- Lucide React (icônes)

## 📁 Structure du projet
- `app/` - Pages et composants Next.js
- `components/` - Composants UI réutilisables
- `lib/` - Utilitaires et helpers
- `hooks/` - Hooks React personnalisés

## 🎨 Personnalisation
- Modifiez `app/page.tsx` pour personnaliser le contenu
- Ajustez les couleurs dans `tailwind.config.ts`
- Remplacez les images par vos propres projets

## 📧 Contact
BEMAZAVA Julio - bemazava.julio@email.com

---
Portfolio créé avec ❤️ et Next.js
